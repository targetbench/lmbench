build_lmbench() {
    set -e
    ARCH=`uname -i`
    SrcPath="/tmp/lmbench.build"
    cd $SrcPath
    myOBJPATH="/tmp/lmbench_test"
    mkdir -p $myOBJPATH
    mkdir -p $myOBJPATH/src
    mkdir -p $myOBJPATH/results
    cp -r -f scripts  $myOBJPATH
    cp src/webpage-lm.tar $myOBJPATH/src
    cp -f CONFIG lmbench_latency lmbench_bandwidth test.sh test_local_bw.sh test_cross_bw.sh test_lat.sh $myOBJPATH
    make OS=lmbench
    mv bin/lmbench/*  $myOBJPATH
    rm -rf bin
    if [ -f "lmbench" ]; then
        sed -i 's/\.\.\/\.\.\//\.\//g' "$myOBJPATH/lmbench"
    fi
    cd $myOBJPATH/../
    tar -cvf lmbench.tar.gz lmbench_test
}

build_lmbench
